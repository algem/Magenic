﻿using System;

namespace jQueryGridASPNET.Controllers
{
    internal class EnableWebSecurity : Attribute
    {
    }
}