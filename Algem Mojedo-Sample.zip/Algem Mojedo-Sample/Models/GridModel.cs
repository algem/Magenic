﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Xml;
using System.Xml.Linq;

namespace jQueryGridASPNET.Models
{
    public class GridModel
    {
        public List<QLessCard> GetQLessCard(int? page, int? limit, string sortBy, 
            string direction, string searchString, out int total)
        {           
            var doc = XDocument.Load(HttpContext.Current.Server.MapPath("~/App_Data/Data.xml"));
            total = doc.Descendants("qLessCard").Count();
            var records = (from p in doc.Descendants("qLessCard")
                           select new QLessCard
                           {
                               Id = int.Parse(p.Attribute("id").Value),
                               SerialNo = p.Attribute("serialNo").Value,
                               DatePurchase = p.Attribute("datePurchase").Value,
                               CardType = p.Attribute("cardType").Value,
                               DiscountType = p.Attribute("discountType").Value,
                               TotalCreditAmt = Decimal.Parse(p.Attribute("totalCreditAmt").Value)
                           }).AsQueryable();
            if (!string.IsNullOrWhiteSpace(searchString))
            {
                records = records.Where(p =>
                       p.Id.ToString().Contains(searchString)
                    || p.SerialNo.Contains(searchString)
                    || p.DatePurchase.Contains(searchString)
                    || p.CardType.Contains(searchString)
                    || p.DiscountType.Contains(searchString)
                    || p.TotalCreditAmt.ToString().Contains(searchString));
            }
            if (!string.IsNullOrEmpty(sortBy) && !string.IsNullOrEmpty(direction))
            {
                if (direction.Trim().ToLower() == "asc")
                {
                    records = SortHelper.OrderBy(records, sortBy);
                }
                else
                {
                    records = SortHelper.OrderByDescending(records, sortBy);
                }
            }
            if (page.HasValue && limit.HasValue)
            {
                int start = (page.Value - 1) * limit.Value;
                records = records.Skip(start).Take(limit.Value);
            }

            return records.ToList();
        }

        public void Save(QLessCard qLessCard)
        {
            // Check required field if value is null
             if (qLessCard.SerialNo == null) {
                System.Web.HttpContext.Current.Response.Write("Serial number is required!");
                return;
            };
            if (qLessCard.DatePurchase == null) {
                 qLessCard.DatePurchase = DateTime.Now.Year.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Day.ToString();
            }
            if (qLessCard.CardType == null) {
                return;
            }
             if (qLessCard.DiscountType == null) {
                 qLessCard.DiscountType = "None";
            };
            string filePath = HttpContext.Current.Server.MapPath("~/App_Data/Data.xml");
            var doc = XDocument.Load(filePath);
            if (qLessCard.Id > 0)
            {
                XElement xqLessCard = (from p in doc.Descendants("qLessCard")
                                     where int.Parse(p.Attribute("id").Value) == qLessCard.Id
                                     select p).FirstOrDefault();
                if (xqLessCard != null)
                {
                    xqLessCard.Attribute("serialNo").Value = qLessCard.SerialNo;
                    xqLessCard.Attribute("datePurchase").Value = qLessCard.DatePurchase;                  
                    xqLessCard.Attribute("cardType").Value = qLessCard.CardType;
                    xqLessCard.Attribute("discountType").Value = qLessCard.DiscountType.ToString();
                    xqLessCard.Attribute("totalCreditAmt").Value = qLessCard.TotalCreditAmt.ToString();                   
                }
            }
            else
            {
                int? maxId = (from p in doc.Descendants("qLessCard") select int.Parse(p.Attribute("id").Value)).OrderByDescending(p => p).FirstOrDefault();
                int newId = maxId.HasValue ? (maxId.Value + 1) : 1;
                XElement node = new XElement("qLessCard");
                node.Add(new XAttribute("id", newId));   
                node.Add(new XAttribute("serialNo", qLessCard.SerialNo));
                node.Add(new XAttribute("datePurchase", qLessCard.DatePurchase));                
                node.Add(new XAttribute("cardType", qLessCard.CardType));
                node.Add(new XAttribute("discountType", qLessCard.DiscountType));              
                node.Add(new XAttribute("totalCreditAmt", qLessCard.TotalCreditAmt));                
                doc.Root.Add(node);
            }
            doc.Save(filePath);           
        }

        public void Remove(int id)
        {
            string filePath = HttpContext.Current.Server.MapPath("~/App_Data/Data.xml");
            var doc = XDocument.Load(filePath);
            XElement xqLessCard = (from p in doc.Descendants("qLessCard")
                                 where int.Parse(p.Attribute("id").Value) == id
                                   select p).FirstOrDefault();
            if (xqLessCard != null)
            {
                xqLessCard.Remove();
                doc.Save(filePath);
            }
        }        
    }
}