﻿/* global window alert jQuery */
/*
 * Gijgo JavaScript Library v0.4.3
 * http://gijgo.com/
 *
 * Copyright 2014, 2015 gijgo.com
 * Released under the MIT license
 */
if (typeof (gj) === "undefined") {
    gj = {};
}
if (typeof (gj.grid) === "undefined") {
    gj.grid = {};
}

gj.grid.configuration = {
    base: {     
        columns: [
            {               
                hidden: false,               
                width: undefined,              
                sortable: false,  // Default              
                type: undefined, //checkbox             
                title: undefined, //TODO: rename to title             
                field: undefined,            
                align: "left",  // Default          
                cssClass: undefined,      
                tooltip: undefined,      
                icon: undefined,           
                events: undefined,           
                format: undefined,             
                decimalDigits: undefined,               
                tmpl: undefined,               
                editor: undefined
            }
        ],
        mapping: {
            
            dataField: "records",
            
            totalRecordsField: "total"
        },
        params: {},
        defaultParams: {
           
            sortBy: "sortBy",
           
            direction: "direction",
           
            page: "page",
           
            limit: "limit"
        },
        
        uiLibrary: "jqueryui",
        style: {
            wrapper: "gj-grid-wrapper",
            table: "gj-grid-table ui-widget-content gj-grid-ui-table",
            loadingCover: "gj-grid-loading-cover",
            loadingText: "gj-grid-loading-text",
            header: {
                cell: "ui-widget-header ui-state-default gj-grid-ui-thead-th",
                sortable: "gj-grid-thead-sortable",
                sortAscIcon: "gj-grid-ui-thead-th-sort-icon ui-icon ui-icon-arrowthick-1-s",
                sortDescIcon: "gj-grid-ui-thead-th-sort-icon ui-icon ui-icon-arrowthick-1-n"
            },
            content: {
                rowHover: "ui-state-hover",
                rowSelected: "ui-state-active"
            },
            pager: {
                cell: "ui-widget-header ui-state-default ui-grid-pager-cell",
                stateDisabled: "ui-state-disabled"
            }
        },

        
        selectionType: 'single',      
        selectionMethod: 'basic',       
        autoLoad: true,
        notFoundText: "No records found on this page.",
        width: undefined,
        minWidth: undefined,
        fontSize: undefined,
        pager: {
          
            enable: false,

            limit: 10,

            sizes: undefined,

            leftControls: [
                $('<div title="First" data-role="page-first" class="ui-icon ui-icon-seek-first ui-grid-icon"></div>'),
                $('<div title="Previous" data-role="page-previous" class="ui-icon ui-icon-seek-prev ui-grid-icon"></div>'),
                $('<div>Page</div>'),
                $('<div></div>').append($('<input type="text" data-role="page-number" class="ui-grid-pager" value="0">')),
                $('<div>of&nbsp;</div>'),
                $('<div data-role="page-label-last">0</div>'),
                $('<div title="Next" data-role="page-next" class="ui-icon ui-icon-seek-next ui-grid-icon"></div>'),
                $('<div title="Last" data-role="page-last" class="ui-icon ui-icon-seek-end ui-grid-icon"></div>'),
                $('<div title="Reload" data-role="page-refresh" class="ui-icon ui-icon-refresh ui-grid-icon"></div>'),
                $('<div></div>').append($('<select data-role="page-size" class="ui-grid-page-sizer"></select>'))
            ],

            rightControls: [
                $('<div>Displaying records&nbsp;</div>'),
                $('<div data-role="record-first">0</div>'),
                $('<div>&nbsp;-&nbsp;</div>'),
                $('<div data-role="record-last">0</div>'),
                $('<div>&nbsp;of&nbsp;</div>'),
                $('<div data-role="record-total">0</div>').css({ "margin-right": "5px" })
            ]
        }
    },

    bootstrap: {
        style: {
            wrapper: "gj-grid-wrapper",
            table: "gj-grid-table table table-bordered table-hover",
            header: {
                cell: "gj-grid-bootstrap-thead-cell",
                sortable: "gj-grid-thead-sortable",
                sortAscIcon: "glyphicon glyphicon-sort-by-alphabet",
                sortDescIcon: "glyphicon glyphicon-sort-by-alphabet-alt"
            },
            content: {
                rowHover: "",
                rowSelected: "active"
            },
            pager: {
                cell: "gj-grid-bootstrap-tfoot-cell",
                stateDisabled: "ui-state-disabled"
            }
        },
        pager: {
            leftControls: [
                $('<button type="button" data-role="page-first" title="First Page" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-step-backward"></span></button>'),
                $('<div>&nbsp;</div>'),
                $('<button type="button" data-role="page-previous" title="Previous Page" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-backward"></span></button>'),
                $('<div>&nbsp;</div>'),
                $('<div>Page</div>'),
                $('<div>&nbsp;</div>'),
                $('<div></div>').append($('<input data-role="page-number" class="form-control input-sm" style="width: 40px; text-align: right;" type="text" value="0">')),
                $('<div>&nbsp;</div>'),
                $('<div>of&nbsp;</div>'),
                $('<div data-role="page-label-last">0</div>'),
                $('<div>&nbsp;</div>'),
                $('<button type="button" data-role="page-next" title="Next Page" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-forward"></span></button>'),
                $('<div>&nbsp;</div>'),
                $('<button type="button" data-role="page-last" title="Last Page" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-step-forward"></span></button>'),
                $('<div>&nbsp;</div>'),
                $('<button type="button" data-role="page-refresh" title="Reload" class="btn btn-default btn-sm"><span class="glyphicon glyphicon-refresh"></span></button>'),
                $('<div>&nbsp;</div>'),
                $('<div></div>').append($('<select data-role="page-size" class="form-control input-sm"></select></div>'))
            ],
            rightControls: [
                $('<div>Displaying records&nbsp;</div>'),
                $('<div data-role="record-first">0</div>'),
                $('<div>&nbsp;-&nbsp;</div>'),
                $('<div data-role="record-last">0</div>'),
                $('<div>&nbsp;of&nbsp;</div>'),
                $('<div data-role="record-total">0</div>').css({ "margin-right": "5px" })
            ]
        }
    }
};
﻿gj.grid.events = {
    beforeEmptyRowInsert: function ($grid, $row) {
        
        $grid.trigger("beforeEmptyRowInsert", [$row]);
    },
    dataBinding: function ($grid, records) {
       
        $grid.trigger("dataBinding", [records]);
    },
    dataBound: function ($grid, records) {
       
        $grid.trigger("dataBound", [records]);
    },
    rowDataBound: function ($grid, $row, id, record) {
       
        $grid.trigger("rowDataBound", [$row, id, record]);
    },
    cellDataBound: function ($grid, $wrapper, id, index, record) {
        
        $grid.trigger("cellDataBound", [$wrapper, id, index, record]);
    },
    rowSelect: function ($grid, $row, id, record) {
       
        $grid.trigger("rowSelect", [$row, id, record]);
    },
    rowUnselect: function ($grid, $row, id, record) {

        $grid.trigger("rowUnselect", [$row, id, record]);

    },
    pageSizeChange: function ($grid, newSize) {

        $grid.trigger("pageSizeChange", [newSize]);

    }
};
﻿gj.grid.private = {

    init: function (jsConfiguration) {
        var options;
        if (!this.data('grid')) {
            options = gj.grid.private.SetOptions(this, jsConfiguration || {});
            gj.grid.private.InitGrid(this);
            gj.grid.private.HeaderRenderer(this);
            gj.grid.private.AppendEmptyRow(this, "&nbsp;");
            gj.grid.private.CreatePager(this);
            if (options.autoLoad) {
                this.reload();
            }
        }
        return this;
    },

    SetOptions: function ($grid, jsConfiguration) {
        var options, htmlConfiguration;
        options = $.extend(true, {}, gj.grid.configuration.base);
        if (jsConfiguration.uiLibrary && jsConfiguration.uiLibrary === "bootstrap") {
            $.extend(true, options, gj.grid.configuration.bootstrap);
        }
        htmlConfiguration = gj.grid.private.GetHTMLConfiguration($grid);
        $.extend(true, options, htmlConfiguration);
        $.extend(true, options, jsConfiguration);
        $grid.data('grid', options);
        return options;
    },

    GetHTMLConfiguration: function ($grid) {
        var result = gj.grid.private.GetAttributes($grid);
        result.columns = [];
        $grid.find("thead>tr>th").each(function () {
            var $el = $(this),
                config = gj.grid.private.GetAttributes($el),
                title = $el.text();
            if (title) {
                config.title = title;
                if (!config.field) {
                    config.field = title;
                }
            }
            result.columns.push(config);
        });
        return result;
    },

    GetAttributes: function ($el) {
        var result;
        result = $el.data();
        if ($el.attr('width')) {
            result['width'] = $el.attr('width');
        }
        if (result.source) {
            result["dataSource"] = result.source;
        }
        return result;
    },

    LoaderSuccessHandler: function ($grid) {
        return function (response) {
            $grid.render(response);
        };
    },

    InitGrid: function ($grid) {
        var data = $grid.data('grid');
        if (!$grid.parent().hasClass(data.style.wrapper)) {
            $grid.wrapAll('<div class="' + data.style.wrapper + '" />');
        }
        if (data.width) {
            $grid.parent().css("width", data.width);
        }
        if (data.minWidth) {
            $grid.css("min-width", data.minWidth);
        }
        if (data.fontSize) {
            $grid.css("font-size", data.fontSize);
        }
        $grid.addClass(data.style.table);
        if ("checkbox" === data.selectionMethod) {
            data.columns = [{ title: '', field: data.dataKey, width: 30, align: 'center', type: 'checkbox' }].concat(data.columns);
        }
        if (data.pager.enable) {
            data.params[data.defaultParams.page] = 1;
            data.params[data.defaultParams.limit] = data.pager.limit;
            $grid.data('grid', data);
        }
        $grid.append($("<tbody/>"));
    },

    HeaderRenderer: function ($grid) {
        var data, $row, $cell, columns, style, i, sortBy, direction;

        data = $grid.data("grid");
        columns = data.columns;
        style = data.style.header;
        sortBy = data.params[data.defaultParams.sortBy];
        direction = data.params[data.defaultParams.direction];

        if ($grid.children("thead").length === 0) {
            $grid.prepend($("<thead />"));
        }

        $row = $("<tr/>");
        for (i = 0; i < columns.length; i += 1) {
            $cell = $("<th/>");
            if (columns[i].width) {
                $cell.css("width", columns[i].width);
            }
            $cell.addClass(style.cell);
            $cell.css("text-align", columns[i].align || "left");
            if (columns[i].sortable) {
                $cell.addClass(style.sortable);
                $cell.bind("click", gj.grid.private.CreateSortHandler($grid, $cell));
            }
            if ("checkbox" === data.selectionMethod && "multiple" === data.selectionType && "checkbox" === columns[i].type) {
                $cell.append($("<input type='checkbox' id='checkAllBoxes' />").hide().click(function () {
                    if (this.checked) {
                        $grid.selectAll();
                    } else {
                        $grid.unSelectAll();
                    }
                }));
            } else {
                $cell.append($("<div style='float: left'/>").text(typeof (columns[i].title) === "undefined" ? columns[i].field : columns[i].title));
                if (sortBy && direction && columns[i].field === sortBy) {
                    $cell.append($("<span style='float: left; margin-left:5px;'/>").addClass("desc" === direction ? style.sortDescIcon : style.sortAscIcon));
                }
            }
            if (columns[i].hidden) {
                $cell.hide();
            }

            $cell.data("cell", columns[i]);
            $row.append($cell);
        }

        $grid.children("thead").empty().append($row);
    },

    CreateSortHandler: function ($grid, $cell) {
        return function () {
            var $icon, data, cellData, params = {};
            if ($grid.count() > 1) {
                data = $grid.data('grid');
                cellData = $cell.data("cell");
                cellData.direction = (cellData.direction === "asc" ? "desc" : "asc");
                params[data.defaultParams.sortBy] = cellData.field;
                params[data.defaultParams.direction] = cellData.direction;
                $grid.reload(params);
            }
        };
    },

    StartLoading: function ($grid) {
        var $tbody, $cover, $loading, width, height, top, data;
        gj.grid.private.StopLoading($grid);
        data = $grid.data('grid');
        if (0 === $grid.outerHeight()) {
            return;
        }
        $tbody = $grid.children("tbody");
        width = $tbody.outerWidth(false);
        height = $tbody.outerHeight(false);
        top = $tbody.prev().outerHeight(false) + parseInt($grid.parent().css("padding-top").replace('px', ''), 10);
        $cover = $("<div data-role='loading-cover' />").addClass(data.style.loadingCover).css({
            width: width,
            height: height,
            top: top
        });
        $loading = $("<div data-role='loading-text'>Loading...</div>").addClass(data.style.loadingText);
        $loading.insertAfter($grid);
        $cover.insertAfter($grid);
        $loading.css({
            top: top + (height / 2) - ($loading.outerHeight(false) / 2),
            left: (width / 2) - ($loading.outerWidth(false) / 2)
        });
    },

    StopLoading: function ($grid) {
        $grid.parent().find("div[data-role='loading-cover']").remove();
        $grid.parent().find("div[data-role='loading-text']").remove();
    },

    CreateAddRowHoverHandler: function ($row, cssClass) {
        return function () {
            $row.addClass(cssClass);
        };
    },

    CreateRemoveRowHoverHandler: function ($row, cssClass) {
        return function () {
            $row.removeClass(cssClass);
        };
    },

    AppendEmptyRow: function ($grid, caption) {
        var data, $row, $cell, $wrapper;
        data = $grid.data('grid');
        $row = $("<tr data-role='emptyRow'/>");
        $cell = $("<td/>").css({ "width": "100%", "text-align": "center" });
        $cell.attr("colspan", $grid.find("thead > tr > th").length);
        $wrapper = $("<div />").html(caption);
        $cell.append($wrapper);
        $row.append($cell);

        gj.grid.events.beforeEmptyRowInsert($grid, $row);

        $grid.append($row);
    },

    LoadData: function ($grid, data, records) {
        var data, records, i, j, recLen, rowCount,
            $tbody, $rows, $row, $checkAllBoxes;

        gj.grid.events.dataBinding($grid, records);
        recLen = records.length;
        gj.grid.private.StopLoading($grid);
        $tbody = $grid.find("tbody");
        if ("checkbox" === data.selectionMethod && "multiple" === data.selectionType) {
            $checkAllBoxes = $grid.find("input#checkAllBoxes");
            $checkAllBoxes.prop("checked", false);
            if (0 === recLen) {
                $checkAllBoxes.hide();
            } else {
                $checkAllBoxes.show();
            }
        }
        $tbody.find("tr[data-role='emptyRow']").remove(); //Remove empty row
        if (0 === recLen) {
            $tbody.empty();
            gj.grid.private.AppendEmptyRow($grid, data.notFoundText);
        }

        $rows = $tbody.children("tr");
        rowCount = $rows.length;
        
        for (i = 0; i < rowCount; i++) {
            if (i < recLen) {
                $row = $rows.eq(i);
                gj.grid.private.RowRenderer($grid, $row, records[i], i);
            } else {
                $tbody.find("tr:gt(" + (i - 1) + ")").remove();
                break;
            }
        }

        for (i = rowCount; i < recLen; i++) {
            gj.grid.private.RowRenderer($grid, null, records[i], i);
        }
        gj.grid.events.dataBound($grid, records);
    },

    RowRenderer: function ($grid, $row, record, position) {
        var id, $cell, i, data, mode;
        data = $grid.data('grid');
        if (!$row || $row.length === 0) {
            mode = "create";
            $row = $($grid.find("tbody")[0].insertRow(position));
            $row.bind({
                "mouseenter.grid": gj.grid.private.CreateAddRowHoverHandler($row, data.style.content.rowHover),
                "mouseleave.grid": gj.grid.private.CreateRemoveRowHoverHandler($row, data.style.content.rowHover)
            });
        } else {
            mode = "update";
            $row.removeClass(data.style.content.rowSelected).off("click");
        }
        id = (data.dataKey && record[data.dataKey]) ? record[data.dataKey] : (position + 1);
        $row.data("row", { id: id, record: record });
        $row.on("click", gj.grid.private.CreateRowClickHandler($grid, id, record));
        for (i = 0; i < data.columns.length; i++) {
            if (mode === "update") {
                $cell = $row.find("td:eq(" + i + ")");
                gj.grid.private.CellRenderer($grid, $cell, data.columns[i], record, id);
            } else {
                $cell = gj.grid.private.CellRenderer($grid, null, data.columns[i], record, id);
                $row.append($cell);
            }
        }
        gj.grid.events.rowDataBound($grid, $row, id, record);
    },

    CellRenderer: function ($grid, $cell, column, record, id, mode) {
        var text, $wrapper, mode;

        if (!$cell || $cell.length === 0) {
            $cell = $("<td/>").css("text-align", column.align || "left");
            $wrapper = $("<div data-role='display' />");
            if (column.cssClass) {
                $wrapper.addClass(column.cssClass);
            }
            $cell.append($wrapper);
            mode = "create";
        } else {
            $wrapper = $cell.find("div");
            mode = "update";
        }

        if ("checkbox" === column.type) {
            if ("create" === mode) {
                $wrapper.append($("<input />").attr("type", "checkbox").val(id).click(function (e) {
                    e.stopPropagation();
                    $grid.setSelected(this.value);
                }));
            } else {
                $wrapper.find("input[type='checkbox']").val(id).prop("checked", false);
            }
        } else if ("icon" === column.type) {
            if ("create" === mode) {
                $wrapper.append($("<span/>")
                    .addClass($grid.data('grid').uiLibrary === "bootstrap" ? "glyphicon" : "ui-icon")
                    .addClass(column.icon).css({ "cursor": "pointer" }));
            }
        } else if (column.tmpl) {
            text = column.tmpl;
            column.tmpl.replace(/\{(.+?)\}/g, function ($0, $1) {
                text = text.replace($0, record[$1]);
            });
            $wrapper.text(text);
        } else {
            gj.grid.private.SetCellText($wrapper, column, record[column.field]);
        }
        if (column.tooltip && "create" === mode) {
            $wrapper.attr("title", column.tooltip);
        }
        //remove all event handlers
        if ("update" === mode) {
            $cell.off();
            $wrapper.off();
        }
        if (column.events) {
            for (var key in column.events) {
                if (column.events.hasOwnProperty(key)) {
                    $cell.on(key, { id: id, field: column.field, record: record }, column.events[key]);
                }
            }
        }
        if (column.editor) {
            $cell.on("click", function () {
                gj.grid.private.OnCellEdit($cell, column, record);
            });
        }
        if (column.hidden) {
            $cell.hide();
        }

        gj.grid.events.cellDataBound($grid, $wrapper, id, column.field, record);

        return $cell;
    },

    OnCellEdit: function ($cell, column, record) {
        var $editorContainer, $editorField;
        if ($cell.attr("data-mode") !== "edit" && column.editor) {
            $cell.find("div[data-role='display']").hide();
            $editorContainer = $cell.find("div[data-role='edit']");
            if ($editorContainer && $editorContainer.length) {
                $editorContainer.show();
                $editorField = $editorContainer.find("input, select, textarea").first();
            } else {
                $editorContainer = $("<div data-role='edit' />");
                $cell.append($editorContainer);
                if (typeof (column.editor) === "function") {
                    column.editor($editorContainer, record[column.field]);
                } else if (typeof (column.editor) === "boolean") {
                    $editorContainer.append("<input type=\"text\" value=\"" + record[column.field] + "\"/>");
                }
                $editorField = $editorContainer.find("input, select, textarea").first();
                $editorField.on("blur", function () { gj.grid.private.OnCellDisplay($cell, column); });
                $editorField.on("keypress", function (e) {
                    if (e.which === 13) {
                        gj.grid.private.OnCellDisplay($cell, column);
                    }
                });
            }
            $editorField.focus().select();
            $cell.attr("data-mode", "edit");
        }
    },

    OnCellDisplay: function ($cell, column) {
        var value, style = "";
        if ($cell.attr("data-mode") === "edit") {
            $editorContainer = $cell.find("div[data-role='edit']");
            $displayContainer = $cell.find("div[data-role='display']");
            value = $editorContainer.find("input, select, textarea").first().val();
            gj.grid.private.SetCellText($displayContainer, column, value);
            $cell.parent().data("row").record[column.field] = value;
            $editorContainer.hide();
            $displayContainer.show();
            if ($cell.find("span.gj-dirty").length === 0) {
                if ($cell.css("padding-top") !== "0px") {
                    style += "margin-top: -" + $cell.css("padding-top") + ";";
                }
                if ($cell.css("padding-left") !== "0px") {
                    style += "margin-left: -" + $cell.css("padding-left") + ";";
                }
                style = style ? " style=\"" + style + "\"" : "";
                $cell.prepend($("<span class=\"gj-dirty\"" + style + "></span>"));
            }
            $cell.attr("data-mode", "display");
        }
    },

    SetCellText: function ($wrapper, column, value) {
        var text = gj.grid.private.FormatText(value, column.type, column.format);
       
        //if (column.decimalDigits && text) {      
        //    text = parseFloat(text).toFixed(column.decimalDigits);
        //} 

        // Added code by Algem 9/9/2020
        if (column.formatMoney && text) {
            text = parseFloat(text)
                .toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 });   
        } 
        if (!column.tooltip) {
            $wrapper.attr("title", text);
        }
      
        $wrapper.text(text);
     },

    // Added code by Algem 9/9/2020
    FormatMoney: function numberWithCommas(x) {
        var parts = x.toString().split(".");
        parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ",");
        return parts.join(".");
    },

    FormatText: function (text, type, format) {
        var dt, day, month;
        if (text && type) {
            switch (type) {
                case "date":
                    if (text.indexOf("/Date(") > -1) {
                        dt = new Date(parseInt(text.substr(6), 10));
                    } else {
                        var parts = text.match(/(\d+)/g);
                        // new Date(year, month, date, hours, minutes, seconds);
                        dt = new Date(parts[0], parts[1] - 1, parts[2], parts[3], parts[4], parts[5]); // months are 0-based
                    }

                    if (dt.format && format) {
                        text = dt.format(format); //using 3rd party plugin "Date Format 1.2.3 by (c) 2007-2009 Steven Levithan <stevenlevithan.com>"
                    } else {
                        day = dt.getDate().toString().length === 2 ? dt.getDate() : "0" + dt.getDate();
                        month = (dt.getMonth() + 1).toString();
                        month = month.length === 2 ? month : "0" + month;
                        text = month + "/" + day + "/" + dt.getFullYear();
                    }
                    break;
                case "money":
                    text = parseFloat(text).toFixed(2).toLocaleString();                 
                    break;
            }
        } else {
            text = (typeof (text) === "undefined" || text === null) ? "" : text.toString();
        }
        return text;
    },

    GetRecords: function (data, response) {
        var records = [];
        if ($.isArray(response)) {
            records = response;
        } else if (data && data.mapping && $.isArray(response[data.mapping.dataField])) {
            records = response[data.mapping.dataField];
        }
        return records;
    },

    CreateRowClickHandler: function ($grid, id, record) {
        return function (e) {
            gj.grid.private._SetSelected($grid, $(this), id);
        };
    },

    SelectRow: function ($grid, data, $row) {
        $row.addClass(data.style.content.rowSelected);

        gj.grid.events.rowSelect($grid, $row, $row.data("row").id, $row.data("row").record);

        if ("checkbox" === data.selectionMethod) {
            $row.find("td:nth-child(1) input[type='checkbox']").prop("checked", true);
        }

        $row.siblings().find("td[data-mode='edit']").each(function () {
            var $cell = $(this),
                column = data.columns[$cell.parent().children().index(this)];
            gj.grid.private.OnCellDisplay($cell, column);
        });
    },

    UnselectRow: function ($grid, data, $row) {
        if ($row.hasClass(data.style.content.rowSelected)) {
            $row.removeClass(data.style.content.rowSelected);

            gj.grid.events.rowUnselect($grid, $row, $row.data("row").id, $row.data("row").record)

            if ("checkbox" === data.selectionMethod) {
                $row.find("td:nth-child(1) input[type='checkbox']").prop("checked", false);
            }
        }
    },

    _SetSelected: function ($grid, $row, id) {
        var data = $grid.data('grid');
        if ($row.hasClass(data.style.content.rowSelected)) {
            gj.grid.private.UnselectRow($grid, data, $row);
        } else {
            gj.grid.private.SelectRow($grid, data, $row);
        }
        if ("single" === data.selectionType) {
            $row.siblings().each(function () {
                gj.grid.private.UnselectRow($grid, data, $(this));
            });
        }
    },

    _GetSelected: function ($grid) {
        var result, data, selections;
        data = $grid.data("grid");
        selections = $grid.find("tbody > tr." + data.style.content.rowSelected);
        if (selections.length > 0) {
            result = $(selections[0]).data("row").id;
        }
        return result;
    },

    GetSelectedRows: function ($grid) {
        var data = $grid.data("grid");
        return $grid.find("tbody > tr." + data.style.content.rowSelected);
    },

    _GetSelections: function ($grid) {
        var result = [],
            $selections = gj.grid.private.GetSelectedRows($grid);
        if (0 < $selections.length) {
            $selections.each(function () {
                result.push($(this).data("row").id);
            });
        }
        return result;
    },

    getRecordById: function ($grid, id) {
        var result = {}, rows, i, rowData;
        rows = $grid.find("tbody > tr");
        for (i = 0; i < rows.length; i++) {
            rowData = $(rows[i]).data("row");
            if (rowData.id === id) {
                result = rowData.record;
                break;
            }
        }
        return result;
    },

    getRowById: function ($grid, id) {
        var result = null, rows, i, rowData;
        rows = $grid.find("tbody > tr");
        for (i = 0; i < rows.length; i++) {
            rowData = $(rows[i]).data("row");
            if (rowData.id === id) {
                result = $(rows[i]);
                break;
            }
        }
        return result;
    },

    getByPosition: function ($grid, position) {
        var result = {}, rows;
        rows = $grid.find("tbody > tr");
        if (rows.length > position) {
            result = $(rows[position-1]).data("row").record;
        }
        return result;
    },

    GetColumnPosition: function (columns, field) {
        var position = -1, i;
        for (i = 0; i < columns.length; i++) {i
            if (columns[i].field === field) {
                position = i;
                break;
            }
        }
        return position;
    },

    GetColumnInfo: function ($grid, index) {
        var i, result = {}, data = $grid.data("grid");
        for (i = 0; i < data.columns.length; i += 1) {
            if (data.columns[i].field === index) {
                result = data.columns[i];
                break;
            }
        }
        return result;
    },

    GetCell: function ($grid, id, index) {
        var result = {}, rows, i, rowData, position;
        position = gj.grid.private.GetColumnPosition($grid, index);
        rows = $grid.find("tbody > tr");
        for (i = 0; i < rows.length; i += 1) {
            rowData = $(rows[i]).data("row");
            if (rowData.id === id) {
                result = $(rows[i].cells[position]).find("div");
                break;
            }
        }
        return result;
    },

    SetCellContent: function ($grid, id, index, value) {
        var column, $cellWrapper = gj.grid.private.GetCell($grid, id, index);
        $cellWrapper.empty();
        if (typeof (value) === "object") {
            $cellWrapper.append(value);
        } else {
            column = gj.grid.private.GetColumnInfo($grid, index);
            gj.grid.private.SetCellText($cellWrapper, column, value);
        }
    },

    CreatePager: function ($grid) {
        var $row, $cell, data, controls, $leftPanel, $rightPanel, $tfoot, $lblPageInfo;

        data = $grid.data('grid');

        if (data.pager.enable) {
            $row = $("<tr/>");
            $cell = $("<th/>").addClass(data.style.pager.cell);
            $cell.attr("colspan", $grid.find("thead > tr > th").length);
            $row.append($cell);

            $leftPanel = $("<div />").css({ "float": "left" });
            $rightPanel = $("<div />").css({ "float": "right" });
            if (/msie/.test(navigator.userAgent.toLowerCase())) {
                $rightPanel.css({ "padding-top": "3px" });
            }

            $cell.append($leftPanel).append($rightPanel);

            $tfoot = $("<tfoot />").append($row);
            $grid.append($tfoot);

            $.each(data.pager.leftControls, function () {
                $leftPanel.append(this);
            });

            $.each(data.pager.rightControls, function () {
                $rightPanel.append(this);
            });

            controls = $grid.find("TFOOT [data-role]");
            for (i = 0; i < controls.length; i++) {
                gj.grid.private.InitPagerControl($(controls[i]), $grid);
            }
        }
    },

    InitPagerControl: function ($control, $grid) {
        var data = $grid.data('grid')
        switch ($control.data("role")) {
            case "page-number":
                $control.bind("keypress", function (e) {
                    if (e.keyCode === 13) {
                        $(this).trigger("change");
                    }
                });
                break;
            case "page-size":
                if (data.pager.sizes && 0 < data.pager.sizes.length) {
                    $control.show();
                    $.each(data.pager.sizes, function () {
                        $control.append($("<option/>").attr("value", this.toString()).text(this.toString()));
                    });
                    $control.change(function () {
                        var newSize = parseInt(this.value, 10);
                        data.params[data.defaultParams.page] = 1;
                        gj.grid.private.SetPageNumber($grid, 1);
                        data.params[data.defaultParams.limit] = newSize;
                        $grid.reload();
                        gj.grid.events.pageSizeChange($grid, newSize);
                    });
                    $control.val(data.params[data.defaultParams.limit]);
                } else {
                    $control.hide();
                }
                break;
            case "page-refresh":
                $control.bind("click", function () { $grid.reload(); });
                break;
        }

    },

    ReloadPager: function ($grid, data, response) {
        var totalRecords, page, limit, lastPage, firstRecord, lastRecord;

        totalRecords = response[data.mapping.totalRecordsField];
        if (!totalRecords || isNaN(totalRecords)) {
            totalRecords = 0;
        }
        if (data.pager.enable) {
            page = (0 === totalRecords) ? 0 : data.params[data.defaultParams.page];
            limit = parseInt(data.params[data.defaultParams.limit], 10);
            lastPage = Math.ceil(totalRecords / limit);
            firstRecord = (0 === page) ? 0 : (limit * (page - 1)) + 1;
            lastRecord = (firstRecord + limit) > totalRecords ? totalRecords : (firstRecord + limit) - 1;

            controls = $grid.find("TFOOT [data-role]");
            for (i = 0; i < controls.length; i++) {
                gj.grid.private.ReloadPagerControl($(controls[i]), $grid, page, lastPage, firstRecord, lastRecord, totalRecords);
            }

            $grid.find("TFOOT > TR > TH").attr("colspan", $grid.find("thead > tr > th").length);
        }
    },

    ReloadPagerControl: function ($control, $grid, page, lastPage, firstRecord, lastRecord, totalRecords) {
        var data = $grid.data('grid')
        switch ($control.data("role")) {
            case "page-first":
                if (page < 2) {
                    $control.addClass(data.style.pager.stateDisabled).unbind("click");
                } else {
                    $control.removeClass(data.style.pager.stateDisabled).unbind("click").bind("click", gj.grid.private.CreateFirstPageHandler($grid));
                }
                break;
            case "page-previous":
                if (page < 2) {
                    $control.addClass(data.style.pager.stateDisabled).unbind("click");
                } else {
                    $control.removeClass(data.style.pager.stateDisabled).unbind("click").bind("click", gj.grid.private.CreatePrevPageHandler($grid));
                }
                break;
            case "page-number":
                $control.val(page).unbind("change").bind("change", gj.grid.private.CreateChangePageHandler($grid, page, lastPage));
                break;
            case "page-label-last":
                $control.text(lastPage);
                break;
            case "page-next":
                if (lastPage === page) {
                    $control.addClass(data.style.pager.stateDisabled).unbind("click");
                } else {
                    $control.removeClass(data.style.pager.stateDisabled).unbind("click").bind("click", gj.grid.private.CreateNextPageHandler($grid));
                }
                break;
            case "page-last":
                if (lastPage === page) {
                    $control.addClass(data.style.pager.stateDisabled).unbind("click");
                } else {
                    $control.removeClass(data.style.pager.stateDisabled).unbind("click").bind("click", gj.grid.private.CreateLastPageHandler($grid, lastPage));
                }
                break;
            case "record-first":
                $control.text(firstRecord);
                break;
            case "record-last":
                $control.text(lastRecord);
                break;
            case "record-total":
                $control.text(totalRecords);
                break;
        }
    },

    CreateFirstPageHandler: function ($grid) {
        return function () {
            var data = $grid.data('grid');
            data.params[data.defaultParams.page] = 1;
            gj.grid.private.SetPageNumber($grid, 1);
            $grid.reload();
        };
    },

    CreatePrevPageHandler: function ($grid) {
        return function () {
            var data, currentPage, lastPage, newPage;
            data = $grid.data('grid');
            currentPage = data.params[data.defaultParams.page];
            newPage = (currentPage && currentPage > 1) ? currentPage - 1 : 1;
            data.params[data.defaultParams.page] = newPage;
            gj.grid.private.SetPageNumber($grid, newPage);
            $grid.reload();
        };
    },

    CreateNextPageHandler: function ($grid) {
        return function () {
            var data, currentPage;
            data = $grid.data('grid');
            currentPage = data.params[data.defaultParams.page];
            data.params[data.defaultParams.page] = currentPage + 1;
            gj.grid.private.SetPageNumber($grid, currentPage + 1);
            $grid.reload();
        };
    },

    CreateLastPageHandler: function ($grid, lastPage) {
        return function () {
            var data = $grid.data('grid');
            data.params[data.defaultParams.page] = lastPage;
            gj.grid.private.SetPageNumber($grid, lastPage);
            $grid.reload();
        };
    },

    CreateChangePageHandler: function ($grid, currentPage, lastPage) {
        return function (e) {
            var data = $grid.data('grid'),
                newPage = parseInt(this.value, 10);
            if (newPage && !isNaN(newPage) && newPage <= lastPage) {
                data.params[data.defaultParams.page] = newPage;
                $grid.reload();
            } else {
                this.value = currentPage;
                alert("Enter a valid page.");
            }
        };
    },

    SetPageNumber: function ($grid, value) {
        $grid.find("TFOOT [data-role='page-number']").val(value);
    },

    GetAll: function ($grid) {
        var result = [],
            rows = $grid.find("tbody > tr"),
            i = 0;

        for (; i < rows.length; i++) {
            result.push($(rows[i]).data("row"));
        }
        return result;
    }
};
﻿/** @class Grid */
gj.grid.public = {
    xhr: null,

    reload: function (params) {
        var data, ajaxOptions, records;
        data = this.data('grid');
        $.extend(data.params, params);
        gj.grid.private.StartLoading(this);
        gj.grid.private.HeaderRenderer(this);
        if ($.isArray(data.dataSource)) {
            records = gj.grid.private.GetRecords(data, data.dataSource);
            gj.grid.private.LoadData(this, data, records);
        } else if (typeof (data.dataSource) === "string") {
            ajaxOptions = { url: data.dataSource, data: data.params, success: gj.grid.private.LoaderSuccessHandler(this) };
            if (this.xhr) {
                this.xhr.abort();
            }
            this.xhr = $.ajax(ajaxOptions);
        } else if (typeof(data.dataSource) === "object") {
            if (!data.dataSource.data) {
                data.dataSource.data = {};
            }
            $.extend(data.dataSource.data, data.params);
            ajaxOptions = $.extend(true, {}, data.dataSource); //clone dataSource object
            if (ajaxOptions.dataType === "json" && typeof (ajaxOptions.data) === "object") {
                ajaxOptions.data = JSON.stringify(ajaxOptions.data);
            }
            if (!ajaxOptions.success)
            {
                ajaxOptions.success = gj.grid.private.LoaderSuccessHandler(this);
            }
            if (this.xhr) {
                this.xhr.abort();
            }
            this.xhr = $.ajax(ajaxOptions);
        }
        return this;
    },

    clear: function () {
        var emptyResponse = {}, data = this.data('grid');
        if ("checkbox" === data.selectionMethod) {
            this.find("input#checkAllBoxes").hide();
        }
        emptyResponse[data.mapping.totalRecordsField] = 0;
        this.children("tbody").empty();
        gj.grid.private.StopLoading(this);
        gj.grid.private.AppendEmptyRow(this, "&nbsp;");
        gj.grid.private.ReloadPager(this, data, emptyResponse);
        return this;
    },

    count: function () {
        return $(this).find("tbody tr").length;
    },

   
    render: function (response) {
        var data, records;
        if (!response) {
            return;
        }
        data = this.data('grid');
        if (data) {
            records = gj.grid.private.GetRecords(data, response);
            gj.grid.private.LoadData(this, data, records);
            gj.grid.private.ReloadPager(this, data, response);
        }
    },

    remove: function () {
        var data = this.data('grid');
        $(window).unbind('.grid');
        if (this.parent().hasClass(data.style.wrapper)) {
            this.unwrap();
        }
        this.removeData();
        this.remove();
    },


    destroy: function () {
        $(window).unbind('.grid');
        this.removeClass().empty();
        if (this.parent().hasClass("ui-grid-wrapper")) {
            this.unwrap();
        }
        this.removeData();
        this.off();
    },

    setSelected: function (id) {
        var $row = gj.grid.private.getRowById(this, id);
        if ($row) {
            gj.grid.private._SetSelected(this, $row, id);
        }
    },

    getSelected: function () {
        return gj.grid.private._GetSelected(this);
    },

    getSelections: function () {
        return gj.grid.private._GetSelections(this);
    },

    selectAll: function () {
        var $grid = this,
            data = this.data('grid');
        $grid.find("thead input#checkAllBoxes").prop("checked", true);
        $grid.find("tbody tr").each(function () {
            gj.grid.private.SelectRow($grid, data, $(this));
        });
    },

    unSelectAll: function () {
        var $grid = $(this),
            data = this.data('grid');
        this.find("thead input#checkAllBoxes").prop("checked", false);
        this.find("tbody tr").each(function () {
            gj.grid.private.UnselectRow($grid, data, $(this));
        });
    },

    getById: function (id) {
        return gj.grid.private.getRecordById(this, id);
    },

    get: function (position) {
        return gj.grid.private.getByPosition(this, position);
    },

    getAll: function () {
        return gj.grid.private.GetAll(this);
    },

    showColumn: function (field) {
        var data = this.data('grid'),
            position = gj.grid.private.GetColumnPosition(data.columns, field);

        if (position > -1) {
            this.find("thead>tr>th:eq(" + position + ")").show();
            $.each(this.find("tbody>tr"), function () {
                $(this).find("td:eq(" + position + ")").show();
            });
            data.columns[position].hidden = false;
        }

        return this;
    },

    hideColumn: function (field) {
        var data = this.data('grid'),
            position = gj.grid.private.GetColumnPosition(data.columns, field);

        if (position > -1) {
            this.find("thead>tr>th:eq(" + position + ")").hide();
            $.each(this.find("tbody>tr"), function () {
                $(this).find("td:eq(" + position + ")").hide();
            });
            data.columns[position].hidden = true;
        }

        return this;
    },

    addRow: function (record) {
        var position = this.count();
        gj.grid.private.RowRenderer(this, null, record, position);
        return this;
    },

    updateRow: function (id, record) {
        var $row = gj.grid.private.getRowById(this, id);
        gj.grid.private.RowRenderer(this, $row, record, $row.index());
        return this;        
    },
    
    //TODO: needs to be removed
    setCellContent: function (id, index, value) {
        gj.grid.private.SetCellContent(this, id, index, value);
    },

    removeRow: function (id) {
        var $row = gj.grid.private.getRowById(this, id);
        if ($row) {
            $row.remove();
        }
        return this;
    }
};

(function ($) {
    $.fn.grid = function (method) {
        if (typeof method === 'object' || !method) {
            function Grid() {
                var self = this;
                $.extend(self, gj.grid.public);
            };
            var grid = new Grid();
            $.extend(this, grid);
            return gj.grid.private.init.apply(this, arguments);
        } else if (gj.grid.public[method]) {
            return gj.grid.public[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else {
            throw "Method " + method + " does not exist.";
        }
    };
})(jQuery);
