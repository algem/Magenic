﻿using MvcContrib.UI.InputBuilder.Attributes;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;


namespace jQueryGridASPNET.Models
{
    public class QLessCard
    {

        public int Id { get; set; }

        public string SerialNo { get; set; }      // Card Serial Number

        public string DatePurchase { get; set; }  // Date picker

        public string CardType { get; set; }      // Regular,Discounted

        public string DiscountType { get; set; }  // None, Senior,PWD

        public Decimal TotalCreditAmt { get; set; }  // Amount paid
    }
}